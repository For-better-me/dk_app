"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _tslib = require("../../npm/tslib/tslib.js");

var tslib_1 = _interopRequireWildcard(_tslib);

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _user = require("../../apis/user.js");

var _user2 = _interopRequireDefault(_user);

var _common = require("../../apis/common.js");

var _common2 = _interopRequireDefault(_common);

var _index3 = require("../../npm/@tarojs/redux/index.js");

var _actions = require("../../store/actions.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var mine1 = "/assets/img/mine1.png";
var mine2 = "/assets/img/mine2.png";
var mine3 = "/assets/img/mine3.png";
var mine5 = "/assets/img/mine5.png";
var mine6 = "/assets/img/mine6.png";
var Bg = "/assets/img/bg-mine.png";
var avatar = "/assets/img/avatar.png";

var Mine = (_temp2 = _class = function (_BaseComponent) {
  _inherits(Mine, _BaseComponent);

  function Mine() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Mine);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Mine.__proto__ || Object.getPrototypeOf(Mine)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["anonymousState__temp", "$compid__17", "$compid__18", "$compid__19", "$compid__20", "$compid__21", "$compid__22", "user", "Bg", "avatar", "mine5", "personInfo", "userInfo"], _this.config = {
      navigationBarTitleText: '个人中心'
    }, _this.getPersonInfo = function () {
      _user2.default.getPersonalConfig().then(function (data) {
        _this.setState({ personInfo: data, userInfo: data.user_info });
      });
    }, _this.customComponents = ["NavItem", "AtIcon", "JTabBar"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Mine, [{
    key: "_constructor",
    value: function _constructor() {
      _get(Mine.prototype.__proto__ || Object.getPrototypeOf(Mine.prototype), "_constructor", this).apply(this, arguments);

      this.state = {
        personInfo: {
          balance: '--',
          coupon_number: '--',
          history_total_integral: '--',
          current_integral: '--'
        },
        userInfo: {
          avatar: '',
          nickname: ''
        }
      };
      this.$$refs = [];
    }
  }, {
    key: "componentDidShow",
    value: function componentDidShow() {
      this.getPersonInfo();
    }
  }, {
    key: "getUserInfo",
    value: function getUserInfo(user) {
      var _this2 = this;

      var data = {
        avatar: user.detail.userInfo.avatarUrl,
        nickname: user.detail.userInfo.nickName
      };
      _common2.default.updateUserInfo(data).then(function (res) {
        _this2.setState({
          userInfo: data
        });
      });
    }
  }, {
    key: "navTo",
    value: function navTo(url) {
      _index2.default.navigateTo({ url: url });
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__17 = (0, _index.genCompid)(__prefix + "$compid__17");
      var $compid__18 = (0, _index.genCompid)(__prefix + "$compid__18");
      var $compid__19 = (0, _index.genCompid)(__prefix + "$compid__19");
      var $compid__20 = (0, _index.genCompid)(__prefix + "$compid__20");
      var $compid__21 = (0, _index.genCompid)(__prefix + "$compid__21");
      var $compid__22 = (0, _index.genCompid)(__prefix + "$compid__22");

      var personInfo = this.__state.personInfo;
      var user = this.__state.userInfo;
      var anonymousState__temp = user.avatar == '' ? (0, _index.internal_inline_style)({ background: 'none' }) : null;
      _index.propsManager.set({
        "icon": mine1,
        "title": "\u6211\u7684\u8BA2\u5355",
        "url": "/pages/orderMy/index"
      }, $compid__17);
      _index.propsManager.set({
        "icon": mine2,
        "title": "\u6536\u8D27\u5730\u5740",
        "url": "/pages/address/index"
      }, $compid__18);
      _index.propsManager.set({
        "icon": mine3,
        "title": "\u5145\u503C\u9001\u793C",
        "url": "/pages/balance/index"
      }, $compid__19);
      _index.propsManager.set({
        "icon": mine6,
        "title": "\u5173\u4E8E\u6BCF\u5473\u5341\u8DB3",
        "url": "/pages/aboutUs/index"
      }, $compid__20);
      _index.propsManager.set({
        "value": "chevron-right",
        "size": "20",
        "color": "#999"
      }, $compid__21);
      _index.propsManager.set({
        "index": 3
      }, $compid__22);
      Object.assign(this.__state, {
        anonymousState__temp: anonymousState__temp,
        $compid__17: $compid__17,
        $compid__18: $compid__18,
        $compid__19: $compid__19,
        $compid__20: $compid__20,
        $compid__21: $compid__21,
        $compid__22: $compid__22,
        user: user,
        Bg: Bg,
        avatar: avatar,
        mine5: mine5
      });
      return this.__state;
    }
  }]);

  return Mine;
}(_index.Component), _class.$$events = ["getUserInfo", "navTo"], _class.$$componentPath = "pages/mine/index", _temp2);
Mine = tslib_1.__decorate([(0, _index3.connect)(function (_ref2) {
  var reducer = _ref2.reducer;
  return {
    countCar: reducer.countCar
  };
}, function (dispatch) {
  return {
    setTab: function setTab(num) {
      dispatch((0, _actions.SetTab)(num));
    }
  };
})], Mine);
exports.default = Mine;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(Mine, true));