"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _order = require("../../apis/order.js");

var _order2 = _interopRequireDefault(_order);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Orders = (_temp2 = _class = function (_BaseComponent) {
  _inherits(Orders, _BaseComponent);

  function Orders() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Orders);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Orders.__proto__ || Object.getPrototypeOf(Orders)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["loopArray19", "$compid__42", "paySort", "orderList"], _this.config = {
      navigationBarTitleText: '我的订单'
    }, _this.scrollToLower = function () {
      if (_this.postData.page++ > _this.total) {
        _index2.default.showToast({
          title: '没有更多了',
          icon: 'none'
        });
        return;
      }
      _this.init();
    }, _this.orderListener = function (id, type) {
      var orderList = [];
      if (type == 0) {
        //删除
        orderList = _this.state.orderList.filter(function (el) {
          return el.id != id;
        });
      } else {
        orderList = _this.state.orderList.map(function (el) {
          if (id == el.id) {
            el.status = type;
          }
          return el;
        });
      }
      _this.setState({ orderList: orderList });
    }, _this.customComponents = ["OrderItem", "NoData"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Orders, [{
    key: "_constructor",
    value: function _constructor(props) {
      _get(Orders.prototype.__proto__ || Object.getPrototypeOf(Orders.prototype), "_constructor", this).call(this, props);

      this.postData = {
        limit: 10,
        page: 1
      };
      this.total = 0;

      this.state = {
        paySort: 1,
        orderList: []
      };
      this.$$refs = [];
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      this.init();
    }
  }, {
    key: "switchType",
    value: function switchType(paySort) {
      var _this2 = this;

      this.postData.page = 1;
      this.setState({ paySort: paySort, orderList: [] }, function () {
        _this2.init();
      });
    }
  }, {
    key: "init",
    value: function init() {
      var _this3 = this;

      var data = _extends({
        type: this.state.paySort
      }, this.postData);
      _order2.default.orderList(data).then(function (res) {
        var orderList = _this3.state.orderList.concat(res.list);
        _this3.total = res.total_page;
        _this3.setState({ orderList: orderList });
      });
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      var _this4 = this;

      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__42 = (0, _index.genCompid)(__prefix + "$compid__42");

      var _state = _extends({}, this.__state),
          paySort = _state.paySort;

      var orderList = this.__state.orderList;
      var loopArray19 = orderList.length > 0 ? orderList.map(function (order, _anonIdx) {
        order = {
          $original: (0, _index.internal_get_original)(order)
        };
        var $compid__41 = (0, _index.genCompid)(__prefix + "UfGeNyqqdr" + _anonIdx);
        orderList.length > 0 && _index.propsManager.set({
          "orderInfo": order.$original,
          "eventListener": _this4.orderListener
        }, $compid__41);
        return {
          $compid__41: $compid__41,
          $original: order.$original
        };
      }) : [];
      orderList.length == 0 && _index.propsManager.set({
        "tip": "\u6682\u65E0\u8BB0\u5F55"
      }, $compid__42);
      Object.assign(this.__state, {
        loopArray19: loopArray19,
        $compid__42: $compid__42
      });
      return this.__state;
    }
  }]);

  return Orders;
}(_index.Component), _class.$$events = ["switchType", "scrollToLower"], _class.$$componentPath = "pages/orderMy/index", _temp2);
exports.default = Orders;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(Orders, true));