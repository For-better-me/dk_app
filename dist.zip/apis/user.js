'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _http2 = require('../utils/http.js');

var _http3 = _interopRequireDefault(_http2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var UserApi = function () {
  function UserApi() {
    _classCallCheck(this, UserApi);
  }

  _createClass(UserApi, null, [{
    key: 'getPersonalConfig',
    value: function getPersonalConfig() {
      return (0, _http3.default)({
        url: '/api/user/personal',
        method: 'POST'
      });
    }
  }, {
    key: 'recharge',
    value: function recharge() {
      return (0, _http3.default)({
        url: '/api/Recharge/getList',
        method: 'POST'
      });
    }
  }, {
    key: 'rechargeLog',
    value: function rechargeLog(data) {
      return (0, _http3.default)({
        url: '/api/Balancelog/info',
        method: 'POST',
        data: data
      });
    }
  }, {
    key: 'rechargePay',
    value: function rechargePay(data) {
      return (0, _http3.default)({
        url: '/api/recharge/balanceCharge',
        method: 'POST',
        data: data
      });
    }
  }, {
    key: 'IntegralLog',
    value: function IntegralLog(data) {
      return (0, _http3.default)({
        url: '/api/Integrallog/getList',
        method: 'POST',
        data: data
      });
    }
  }, {
    key: 'CouponLog',
    value: function CouponLog() {
      return (0, _http3.default)({
        url: '/api/Coupon/getList',
        method: 'POST'
      });
    }
  }, {
    key: 'CouponAdd',
    value: function CouponAdd(data) {
      return (0, _http3.default)({
        url: '/api/Coupon/addInfo',
        method: 'POST',
        data: data,
        loading: false
      });
    }
  }, {
    key: 'InviteInfo',
    value: function InviteInfo() {
      return (0, _http3.default)({
        url: '/api/Invite/info',
        method: 'POST'
      });
    }
  }, {
    key: 'InviteAdd',
    value: function InviteAdd(data) {
      return (0, _http3.default)({
        url: '/api/Invite/addInfo',
        method: 'POST',
        data: data
      });
    }
  }]);

  return UserApi;
}();

exports.default = UserApi;