"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _tslib = require("../../npm/tslib/tslib.js");

var tslib_1 = _interopRequireWildcard(_tslib);

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _shoppingCar = require("../../apis/shoppingCar.js");

var _shoppingCar2 = _interopRequireDefault(_shoppingCar);

var _index3 = require("../../npm/@tarojs/redux/index.js");

var _actions = require("../../store/actions.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var carBg = "/assets/img/bg-car.png";
var nodataImg = "/assets/img/nodata-car.png";

var ShoppingCar = (_temp2 = _class = function (_BaseComponent) {
  _inherits(ShoppingCar, _BaseComponent);

  function ShoppingCar() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, ShoppingCar);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = ShoppingCar.__proto__ || Object.getPrototypeOf(ShoppingCar)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["anonymousState__temp", "loopArray41", "$compid__159", "$compid__160", "$compid__161", "$compid__162", "carBg", "shoppingCarList", "diffVal", "isDel", "totalPrice", "totalPrice2", "deliverStandard", "setCountCar", "countCar", "deliveryType", "setGoodsBuying"], _this.config = {
      navigationBarTitleText: '购物车'
    }, _this.getListDiv = function (data) {}, _this.changeTotal = function () {
      var state = _this.allCheckState();
      var shoppingCarList = _this.state.shoppingCarList.map(function (el) {
        if (!(el.status == 1 || el.status == 2 || el.status == 3)) {
          el.isCheck = !state;
        }
        return el;
      });
      _this.computePrice();
      _this.setState({
        shoppingCarList: shoppingCarList
      });
    }, _this.changeOne = function (val, id) {
      var shoppingCarList = _this.state.shoppingCarList.map(function (el) {
        if (el.id == id) {
          el.isCheck = val;
        }
        return el;
      });
      _this.computePrice();
      _this.setState({
        shoppingCarList: shoppingCarList
      });
    }, _this.switchTo = function () {
      _index2.default.switchTab({ url: '/pages/index/index' });
    }, _this.changeNumber = function (val, id, type) {
      var self = _this;
      var data = {
        id: id,
        type: type == 'add' ? 1 : 2
      };
      var num = 0;
      _shoppingCar2.default.shoppingCountUpdate(data).then(function (res) {
        var shoppingCarList = self.state.shoppingCarList.map(function (el) {
          if (el.id == id) {
            el.goods_cart_number = val;
          }
          num += el.goods_cart_number;
          return el;
        });
        _this.computePrice();
        _this.setState({
          shoppingCarList: shoppingCarList
        });
      });
    }, _this.del = function () {
      var delArr = _this.state.shoppingCarList.filter(function (el) {
        return el.isCheck;
      });
      var delNum = 0;
      var self = _this;
      var ids = delArr.map(function (el) {
        return el.id;
      });
      _shoppingCar2.default.shoppingCarDel({ ids: ids }).then(function (res) {
        var num = Math.round(self.props.countCar - ids.length);
        self.props.setCountCar(num);
        self.computePrice();
        self.setState({ shoppingCarList: _this.state.shoppingCarList.filter(function (el) {
            return !el.isCheck;
          }) });
      });
    }, _this.settlement = function () {
      var buyArr = _this.state.shoppingCarList.filter(function (el) {
        return el.isCheck && el.stock >= el.goods_cart_number;
      });
      if (buyArr.length == 0) {
        _index2.default.showToast({
          title: '请至少选择一样商品',
          icon: 'none'
        });
        return;
      }
      _this.props.setGoodsBuying(buyArr);
      _index2.default.navigateTo({ url: '/pages/submitOrder/index' });
    }, _this.customComponents = ["JCheckbox", "JInputNumber", "AtIcon", "NoData", "JTabBar"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(ShoppingCar, [{
    key: "_constructor",
    value: function _constructor(props) {
      _get(ShoppingCar.prototype.__proto__ || Object.getPrototypeOf(ShoppingCar.prototype), "_constructor", this).call(this, props);

      this.state = {
        shoppingCarList: [],
        isDel: false,
        totalPrice: 0,
        totalPrice2: 0,
        deliverStandard: 0
      };
      //为什么不可以
      this.$$refs = [];
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      _index2.default.hideTabBar();
    }
  }, {
    key: "componentDidShow",
    value: function componentDidShow() {
      this.getList();
      this.setState({ isDel: false });
    }
  }, {
    key: "computePrice",
    value: function computePrice() {
      var list = this.state.shoppingCarList.filter(function (el) {
        return el.isCheck && el.stock >= el.goods_cart_number;
      });
      var totalPrice = 0;
      var totalPrice2 = 0;
      list.forEach(function (el) {
        totalPrice += el.price * el.goods_cart_number * 100000;
      });
      list.forEach(function (el) {
        if (el.is_special == 1) {
          totalPrice2 += el.price * el.goods_cart_number * 100000;
        }
      });
      totalPrice = Number(totalPrice.toFixed(2)) / 100000;
      totalPrice2 = Number(totalPrice2.toFixed(2)) / 100000;
      this.setState({ totalPrice: totalPrice, totalPrice2: totalPrice2 });
    }
  }, {
    key: "getList",
    value: function getList() {
      var _this2 = this;

      _shoppingCar2.default.shoppingCarList().then(function (data) {
        var shoppingCarList = data.goods_list.map(function (el) {
          el.isCheck = !(el.status == 1 || el.status == 2 || el.status == 3);
          return el;
        });
        _this2.props.setCountCar(data.goods_list.length);
        _this2.setState({
          shoppingCarList: shoppingCarList,
          deliverStandard: data.deliver_standard
        }, _this2.computePrice);
      });
    }
  }, {
    key: "allCheckState",
    value: function allCheckState() {
      var list = this.state.shoppingCarList;
      var state = true;
      for (var i = 0; i < list.length; i++) {
        if (list[i].isCheck == false) {
          state = false;
          break;
        }
      }
      return state;
    }
  }, {
    key: "manageEvent",
    value: function manageEvent(isDel) {
      // if (this.state.shoppingCarList.length == 0) {
      //   return
      // }
      this.setState({ isDel: isDel });
    }
  }, {
    key: "delConfirm",
    value: function delConfirm() {
      var self = this;
      _index2.default.showModal({
        content: '确定将这些商品删除吗？',
        success: function success(res) {
          if (res.confirm) {
            self.del();
          } else if (res.cancel) {
            console.log('用户点击取消');
          }
        }
      });
    }
  }, {
    key: "navTo",
    value: function navTo(id, num) {
      // Taro.navigateTo({
      //   url: `/pages/goodsDetail/index?id=${id}&num=${num}`
      // })
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      var _this3 = this;

      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__159 = (0, _index.genCompid)(__prefix + "$compid__159");
      var $compid__160 = (0, _index.genCompid)(__prefix + "$compid__160");
      var $compid__161 = (0, _index.genCompid)(__prefix + "$compid__161");
      var $compid__162 = (0, _index.genCompid)(__prefix + "$compid__162");

      var _state = this.__state,
          totalPrice = _state.totalPrice,
          totalPrice2 = _state.totalPrice2,
          isDel = _state.isDel,
          deliverStandard = _state.deliverStandard;

      var shoppingCarList = this.__state.shoppingCarList;
      var diffVal = (deliverStandard * 1000 - totalPrice2 * 1000) / 1000;
      var anonymousState__temp = shoppingCarList.length > 0 ? this.allCheckState() : null;
      var loopArray41 = shoppingCarList.length > 0 ? shoppingCarList.map(function (el, _anonIdx) {
        el = {
          $original: (0, _index.internal_get_original)(el)
        };

        var disabledFlag = el.$original.status == 3 || el.$original.status == 1 || el.$original.stock < el.$original.goods_cart_number;
        var $compid__157 = (0, _index.genCompid)(__prefix + "yZYkYLVQIi" + _anonIdx);
        shoppingCarList.length > 0 && _index.propsManager.set({
          "disabled": disabledFlag && !_this3.__state.isDel,
          "value": el.$original.isCheck,
          "extra": el.$original.id,
          "change": _this3.changeOne
        }, $compid__157);
        var $compid__158 = (0, _index.genCompid)(__prefix + "kTYeevbgXy" + _anonIdx);
        shoppingCarList.length > 0 && _index.propsManager.set({
          "extra": el.$original.id,
          "value": el.$original.goods_cart_number,
          "changeNumber": _this3.changeNumber,
          "isZero": false
        }, $compid__158);
        return {
          disabledFlag: disabledFlag,
          $compid__157: $compid__157,
          $compid__158: $compid__158,
          $original: el.$original
        };
      }) : [];
      shoppingCarList.length > 0 && diffVal > 0 && this.__props.deliveryType == 2 && _index.propsManager.set({
        "className": "icon-tip",
        "value": "alert-circle",
        "size": "12",
        "color": "#FAB62C"
      }, $compid__159);
      !(shoppingCarList.length > 0) && _index.propsManager.set({
        "imgSrc": nodataImg,
        "tip": "\u8D2D\u7269\u8F66\u8FD8\u6CA1\u6DFB\u52A0\u5546\u54C1\u54E6~"
      }, $compid__160);
      shoppingCarList.length > 0 && _index.propsManager.set({
        "value": anonymousState__temp,
        "change": this.changeTotal
      }, $compid__161);
      _index.propsManager.set({
        "index": 1
      }, $compid__162);
      Object.assign(this.__state, {
        anonymousState__temp: anonymousState__temp,
        loopArray41: loopArray41,
        $compid__159: $compid__159,
        $compid__160: $compid__160,
        $compid__161: $compid__161,
        $compid__162: $compid__162,
        carBg: carBg,
        diffVal: diffVal
      });
      return this.__state;
    }
  }]);

  return ShoppingCar;
}(_index.Component), _class.$$events = ["manageEvent", "navTo", "switchTo", "delConfirm", "settlement"], _class.$$componentPath = "pages/shoppingCar/index", _temp2);
ShoppingCar = tslib_1.__decorate([(0, _index3.connect)(function (_ref2) {
  var reducer = _ref2.reducer;
  return {
    countCar: reducer.countCar,
    deliveryType: reducer.deliveryType
  };
}, function (dispatch) {
  return {
    setCountCar: function setCountCar(num) {
      dispatch((0, _actions.SetCountCar)(num));
    },
    setTab: function setTab(num) {
      dispatch((0, _actions.SetTab)(num));
    },
    setGoodsBuying: function setGoodsBuying(list) {
      dispatch((0, _actions.SetGoodsBuying)(list));
    }
  };
})], ShoppingCar);
exports.default = ShoppingCar;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(ShoppingCar, true));