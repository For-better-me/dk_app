"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _tslib = require("../../npm/tslib/tslib.js");

var tslib_1 = _interopRequireWildcard(_tslib);

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _index3 = require("../../npm/@tarojs/redux/index.js");

var _order = require("../../apis/order.js");

var _order2 = _interopRequireDefault(_order);

var _actions = require("../../store/actions.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var IconAddr = "/assets/img/icon-addr.png";

var BgBtn = "/assets/img/bg_btn.png";

var SubmitOrder = (_temp2 = _class = function (_BaseComponent) {
  _inherits(SubmitOrder, _BaseComponent);

  function SubmitOrder() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, SubmitOrder);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = SubmitOrder.__proto__ || Object.getPrototypeOf(SubmitOrder)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["anonymousState__temp", "anonymousState__temp2", "loopArray11", "$compid__24", "$compid__25", "$compid__26", "$compid__27", "$compid__28", "$compid__29", "$compid__30", "$compid__31", "IconAddr", "address", "goodsBuyingList", "anonymousState__temp3", "allInfo", "anonymousState__temp4", "BgBtn", "isShowFloat", "couponList", "deliveryTime", "submitInfo", "delivery_type", "delivery_time", "floatLayoutTitle", "floatLayoutType", "integralInfo", "delivery", "couponPrice", "integralPrice", "remark", "integralNum", "weather", "deliveryType", "addrId", "setGoodsBuying"], _this.config = {
      navigationBarTitleText: '确认订单'
    }, _this.openPoints = function (floatLayoutType, floatLayoutTitle, enable) {
      if (enable) {
        _this.setState({ isShowFloat: true, floatLayoutType: floatLayoutType, floatLayoutTitle: floatLayoutTitle });
      }
    }, _this.getInfo = function () {
      var collect_address_id = '0';
      var goods_cart_id = _this.props.goodsBuyingList.map(function (el) {
        return el.id;
      });
      if (_this.props.addrId == '') {
        var list = [];
        var data = { limit: 999, page: 1 };
        _order2.default.addrList(data).then(function (res) {
          _index2.default.showLoading({
            title: '加载中',
            mask: true
          });
          setTimeout(function () {
            _index2.default.hideLoading();
          }, 4000);
          list = res.list;
          var addrDefault = list.filter(function (el) {
            return el.is_default == 2;
          }).length > 0 ? list.filter(function (el) {
            return el.is_default == 2;
          })[0] : list[0];
          if (list.length > 0) {
            collect_address_id = addrDefault.id;
            _this.postData.collect_address_id = collect_address_id;
            var _data = Object.assign({}, _this.postData, { goods_cart_id: goods_cart_id });
            _this.getSubmitInfo(_data).then(function (res) {
              if (_this.props.deliveryType == 1) {
                _this.setState({
                  delivery: '到店自提'
                });
              }
            });
          } else {
            var _data2 = Object.assign({}, _this.postData, { goods_cart_id: goods_cart_id });
            _this.getSubmitInfo(_data2).then(function (res) {
              if (_this.props.deliveryType == 1) {
                _this.setState({
                  delivery: '到店自提'
                });
              }
            });
          }
        });
      } else {
        collect_address_id = _this.props.addrId;
        _this.postData.collect_address_id = collect_address_id;
        var _data3 = Object.assign({}, _this.postData, { goods_cart_id: goods_cart_id });
        _this.getSubmitInfo(_data3).then(function (res) {
          if (_this.props.deliveryType == 1) {
            _this.setState({
              delivery: '到店自提'
            });
          }
        });
      }
    }, _this.newOrder = function () {
      if (!_this.state.address && _this.props.deliveryType != 1) {
        _index2.default.showToast({
          title: '请填写收货地址',
          icon: 'none'
        });
        return;
      }
      if (!_this.state.delivery) {
        _index2.default.showToast({
          title: '请选择配送方式',
          icon: 'none'
        });
        return;
      }
      var invite_user_id = _index2.default.getStorageSync('invite_user_id');
      var goods_cart_id = _this.props.goodsBuyingList.map(function (el) {
        return el.id;
      });
      var delivery_type = _this.props.deliveryType == 1 ? 1 : _this.postData.delivery_type;
      var data = Object.assign({}, _this.postData, { delivery_type: delivery_type, goods_cart_id: goods_cart_id, invite_user_id: invite_user_id });
      _order2.default.submitOrder(data).then(function (sn) {
        _this.props.setGoodsBuying([]);
        _index2.default.redirectTo({
          url: '/pages/pay/index?sn=' + sn + '&&price=' + _this.state.submitInfo.payment_total_price
        });
      });
    }, _this.deliveryTimeChange = function (type, desc, level, delivery_time, delivery_time_index) {
      if (level == 1) {
        _this.setState({
          delivery_type: type
        });
      } else if (level == 2) {
        _this.postData.delivery_type = type;
        _this.postData.delivery_time = delivery_time ? delivery_time : 0;
        _this.delivery_time_index = type == 2 ? delivery_time_index : -1;
        _this.deliveryFast = type == 3 ? delivery_time_index : -1;
        _this.getSubmitInfo();
        _this.setState({
          delivery: desc + ' ' + delivery_time,
          isShowFloat: false
        });
      }
    }, _this.integralChange = function (num, integralPrice, integral) {
      _this.postData.integral_number = integral || 0;
      _this.getSubmitInfo();
      _this.setState({ integralPrice: integralPrice, integralNum: num });
    }, _this.onCloseFloat = function () {
      _this.setState({
        isShowFloat: false
      });
      if (_this.state.floatLayoutType == 1) {} else if (_this.state.floatLayoutType == 2) {} else if (_this.state.floatLayoutType == 3) {
        // if (this.state.delivery == '') {
        //   let delivery = '普通配送' + ' ' + this.state.deliveryTime[0]
        //   this.setState({ delivery })
        // }
        _this.getSubmitInfo();
      }
    }, _this.couponHandle = function (id) {
      _this.postData.user_coupon_id = id;
      _this.getSubmitInfo().then(function (res) {
        _this.setState({
          isShowFloat: false,
          couponPrice: res.avoid_price
        });
      }).catch(function (err) {
        _this.postData.user_coupon_id = 0;
      });
    }, _this.customComponents = ["AtIcon", "AtFloatLayout", "Coupon", "IntegralComp", "Distribution"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(SubmitOrder, [{
    key: "_constructor",
    value: function _constructor(props) {
      _get(SubmitOrder.prototype.__proto__ || Object.getPrototypeOf(SubmitOrder.prototype), "_constructor", this).call(this, props);

      this.postData = {
        user_coupon_id: 0,
        delivery_type: 2,
        integral_number: 0,
        delivery_time: '17:00',
        collect_address_id: '0',
        avoid_price: 0,
        desc: ""
      };
      this.delivery_time_index = -1;
      this.deliveryFast = -1;

      this.state = {
        isShowFloat: false,
        address: null,
        couponList: [],
        deliveryTime: [],
        submitInfo: {},
        delivery_type: 2,
        delivery_time: '',
        floatLayoutTitle: '',
        floatLayoutType: 1,
        integralInfo: {},
        delivery: '',
        couponPrice: 0,
        integralPrice: 0,
        remark: '',
        integralNum: 0,
        weather: ''
      };
      this.$$refs = [];
    }
  }, {
    key: "componentDidShow",
    value: function componentDidShow() {
      this.getInfo();
    }
  }, {
    key: "getSubmitInfo",
    value: function getSubmitInfo(dataR) {
      var _this2 = this;

      var goods_cart_id = this.props.goodsBuyingList.map(function (el) {
        return el.id;
      });
      var delivery_type = this.props.deliveryType == 1 ? 1 : this.postData.delivery_type;
      var dataDefault = Object.assign({}, this.postData, { goods_cart_id: goods_cart_id });
      var data = dataR || dataDefault;
      data.delivery_type = delivery_type;
      console.log('delivery_type', delivery_type, data);
      return new Promise(function (resolve, reject) {
        _order2.default.getSubmitInfo(data).then(function (res) {
          var integralInfo = {
            current_integral: res.current_integral,
            max_current_integral: res.max_current_integral,
            integral_scale: res.integral_scale,
            integral_use_price: res.integral_use_price,
            integral_number: res.integral_number ? res.integral_number : 0
          };
          _this2.setState({
            address: res.collect_address_info,
            deliveryTime: res.delivery_time,
            couponList: res.available_list,
            submitInfo: res,
            integralInfo: integralInfo,
            weather: res.weather
          });
          resolve(res);
        }).catch(function (err) {
          reject(err);
        });
      });
    }
  }, {
    key: "chooseAddr",
    value: function chooseAddr() {
      _index2.default.navigateTo({ url: '/pages/address/index?flag=1' });
    }
  }, {
    key: "changeRemark",
    value: function changeRemark(e) {
      this.postData.desc = e.detail.value;
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      var _this3 = this;

      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__24 = (0, _index.genCompid)(__prefix + "$compid__24");
      var $compid__25 = (0, _index.genCompid)(__prefix + "$compid__25");
      var $compid__26 = (0, _index.genCompid)(__prefix + "$compid__26");
      var $compid__27 = (0, _index.genCompid)(__prefix + "$compid__27");
      var $compid__28 = (0, _index.genCompid)(__prefix + "$compid__28");
      var $compid__29 = (0, _index.genCompid)(__prefix + "$compid__29");
      var $compid__30 = (0, _index.genCompid)(__prefix + "$compid__30");
      var $compid__31 = (0, _index.genCompid)(__prefix + "$compid__31");

      var goodsBuyingList = this.__props.goodsBuyingList;
      var address = this.__state.address;
      var allInfo = this.__state.submitInfo;
      var anonymousState__temp = (0, _index.internal_inline_style)({ display: this.__state.isShowFloat ? 'none' : 'flex' });
      var anonymousState__temp2 = (0, _index.internal_inline_style)({ display: this.__state.isShowFloat ? 'none' : 'flex' });
      var anonymousState__temp3 = Boolean(this.__state.couponList.length);
      var anonymousState__temp4 = Boolean(allInfo.max_current_integral && allInfo.max_current_integral > allInfo.integral_scale);
      var loopArray11 = this.__state.floatLayoutType == 1 ? this.__state.couponList.map(function (el, _anonIdx3) {
        el = {
          $original: (0, _index.internal_get_original)(el)
        };
        var $compid__23 = (0, _index.genCompid)(__prefix + "VYnBuxtMND" + _anonIdx3);
        _this3.__state.isShowFloat && _this3.__state.floatLayoutType == 1 && _index.propsManager.set({
          "coupon": el.$original,
          "choosedHandle": _this3.couponHandle,
          "isChoose": true
        }, $compid__23);
        return {
          $compid__23: $compid__23,
          $original: el.$original
        };
      }) : [];
      this.__props.deliveryType != 1 && _index.propsManager.set({
        "value": "chevron-right",
        "size": "20",
        "color": "#999"
      }, $compid__24);
      _index.propsManager.set({
        "value": "chevron-right",
        "size": "16",
        "color": "#999",
        "className": "mar-l-10"
      }, $compid__25);
      _index.propsManager.set({
        "value": "chevron-right",
        "size": "16",
        "color": "#999",
        "className": "mar-l-10"
      }, $compid__26);
      _index.propsManager.set({
        "value": "chevron-right",
        "size": "16",
        "color": "#999",
        "className": "mar-l-10"
      }, $compid__27);
      this.__state.weather && _index.propsManager.set({
        "className": "icon-tip",
        "value": "alert-circle",
        "size": "12",
        "color": "#FAB62C"
      }, $compid__28);
      this.__state.isShowFloat && _index.propsManager.set({
        "isOpened": true,
        "title": this.__state.floatLayoutTitle,
        "onClose": this.onCloseFloat
      }, $compid__29);
      this.__state.isShowFloat && this.__state.floatLayoutType == 2 && _index.propsManager.set({
        "integralNum": this.__state.integralNum,
        "integralInfo": this.__state.integralInfo,
        "change": this.integralChange
      }, $compid__30);
      this.__state.isShowFloat && this.__state.floatLayoutType == 3 && _index.propsManager.set({
        "deliveryFast": this.deliveryFast,
        "deliveryType": this.__state.delivery_type,
        "deliveryTime": this.delivery_time_index,
        "deliveryTimeList": this.__state.deliveryTime,
        "switch": this.deliveryTimeChange
      }, $compid__31);
      Object.assign(this.__state, {
        anonymousState__temp: anonymousState__temp,
        anonymousState__temp2: anonymousState__temp2,
        loopArray11: loopArray11,
        $compid__24: $compid__24,
        $compid__25: $compid__25,
        $compid__26: $compid__26,
        $compid__27: $compid__27,
        $compid__28: $compid__28,
        $compid__29: $compid__29,
        $compid__30: $compid__30,
        $compid__31: $compid__31,
        IconAddr: IconAddr,
        goodsBuyingList: goodsBuyingList,
        anonymousState__temp3: anonymousState__temp3,
        allInfo: allInfo,
        anonymousState__temp4: anonymousState__temp4,
        BgBtn: BgBtn
      });
      return this.__state;
    }
  }]);

  return SubmitOrder;
}(_index.Component), _class.$$events = ["chooseAddr", "openPoints", "changeRemark", "newOrder"], _class.$$componentPath = "pages/submitOrder/index", _temp2);
SubmitOrder = tslib_1.__decorate([(0, _index3.connect)(function (_ref2) {
  var reducer = _ref2.reducer;
  return {
    deliveryType: reducer.deliveryType,
    goodsBuyingList: reducer.goodsBuyingList,
    addrId: reducer.addrId
  };
}, function (dispatch) {
  return {
    setGoodsBuying: function setGoodsBuying(list) {
      dispatch((0, _actions.SetGoodsBuying)(list));
    }
  };
})], SubmitOrder);
exports.default = SubmitOrder;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(SubmitOrder, true));