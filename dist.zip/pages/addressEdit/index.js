"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _order = require("../../apis/order.js");

var _order2 = _interopRequireDefault(_order);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var AddressEdit = (_temp2 = _class = function (_BaseComponent) {
  _inherits(AddressEdit, _BaseComponent);

  function AddressEdit() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, AddressEdit);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = AddressEdit.__proto__ || Object.getPrototypeOf(AddressEdit)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["$compid__44", "$compid__45", "addr", "isOpened"], _this.config = {
      navigationBarTitleText: '新建地址'
    }, _this.save = function () {
      var data = _this.state.addr;
      var id = _this.$router.params.id;
      if (data.name && data.phone && data.address && data.address_detail) {
        if (id == '0') {
          _order2.default.addrNew(data).then(function (res) {
            _index2.default.showToast({
              title: '新建地址成功',
              complete: function complete() {
                _index2.default.navigateBack();
              }
            });
          });
        } else {
          data.id = id;
          _order2.default.addrUpdate(data).then(function (res) {
            _index2.default.showToast({
              title: '更新地址成功',
              complete: function complete() {
                _index2.default.navigateBack();
              }
            });
          });
        }
      } else {
        _index2.default.showToast({
          title: '请完善地址信息',
          icon: 'none'
        });
      }
      console.log(_this.state.addr);
    }, _this.onRegionChange = function (e) {
      var _e$detail$code = _slicedToArray(e.detail.code, 3),
          province_id = _e$detail$code[0],
          city_id = _e$detail$code[1],
          area_id = _e$detail$code[2];

      var addr = Object.assign({}, _this.state.addr, { 'address': e.detail.value.join(' '), province_id: province_id, city_id: city_id, area_id: area_id });
      _this.setState({
        addr: addr
      });
    }, _this.switchChange = function (e) {
      console.log(e.detail.value);
      var addr = Object.assign({}, _this.state.addr, { is_default: e.detail.value ? 2 : 1 });
      _this.setState({
        addr: addr
      });
    }, _this.location = function () {
      var self = _this;
      if (self.state.addr.lat && self.state.addr.lng) {
        var latitude = self.state.addr.lat;
        var longitude = self.state.addr.lng;
        _index2.default.chooseLocation({
          latitude: latitude,
          longitude: longitude,
          success: function success(res) {
            var addr = Object.assign({}, self.state.addr, { lng: res.longitude, lat: res.latitude, address: res.name });
            self.setState({ addr: addr });
          }
        });
      } else {
        _index2.default.showLoading({
          title: '正在加载地图...'
        });
        _index2.default.getLocation({
          type: 'gcj02',
          isHighAccuracy: true,
          success: function success(res) {
            setTimeout(function () {
              _index2.default.hideLoading();
            }, 3000);
            var latitude = res.latitude;
            var longitude = res.longitude;
            _index2.default.chooseLocation({
              latitude: latitude,
              longitude: longitude,
              success: function success(res) {
                var addr = Object.assign({}, self.state.addr, { lng: res.longitude, lat: res.latitude, address: res.name });
                self.setState({ addr: addr });
              }
            });
          },
          fail: function fail() {
            self.setState({
              isOpened: true
            });
          }
        });
      }
    }, _this.customComponents = ["AtIcon", "AtCurtain"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(AddressEdit, [{
    key: "_constructor",
    value: function _constructor(props) {
      _get(AddressEdit.prototype.__proto__ || Object.getPrototypeOf(AddressEdit.prototype), "_constructor", this).call(this, props);

      this.state = {
        addr: {
          is_default: 1
        },
        isOpened: false
      };
      this.$$refs = [];
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      if (this.$router.params.id != '0') {
        _index2.default.setNavigationBarTitle({ 'title': '编辑地址' });
        this.init(this.$router.params.id);
      }
    }
  }, {
    key: "init",
    value: function init(id) {
      var _this2 = this;

      _order2.default.addrInfo({ id: id }).then(function (addr) {
        _this2.setState({ addr: addr });
      });
    }
  }, {
    key: "blurEvent",
    value: function blurEvent(key, e) {
      var addr = Object.assign({}, this.state.addr, _defineProperty({}, key, e.detail.value));
      this.setState({
        addr: addr
      });
    }
  }, {
    key: "openSetting",
    value: function openSetting(e) {
      if (e.detail.authSetting['scope.userLocation']) {
        this.location();
        this.setState({
          isOpened: false
        });
      }
    }
  }, {
    key: "onClose",
    value: function onClose() {
      this.setState({
        isOpened: false
      });
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__44 = (0, _index.genCompid)(__prefix + "$compid__44");
      var $compid__45 = (0, _index.genCompid)(__prefix + "$compid__45");

      var addr = this.__state.addr;
      _index.propsManager.set({
        "value": "chevron-right",
        "size": "20",
        "color": "#999"
      }, $compid__44);
      _index.propsManager.set({
        "closeBtnPosition": "top-right",
        "isOpened": this.__state.isOpened,
        "onClose": this.onClose.bind(this)
      }, $compid__45);
      Object.assign(this.__state, {
        $compid__44: $compid__44,
        $compid__45: $compid__45
      });
      return this.__state;
    }
  }]);

  return AddressEdit;
}(_index.Component), _class.$$events = ["blurEvent", "location", "switchChange", "save", "openSetting"], _class.$$componentPath = "pages/addressEdit/index", _temp2);
exports.default = AddressEdit;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(AddressEdit, true));