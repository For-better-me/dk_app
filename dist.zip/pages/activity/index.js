"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _tslib = require("../../npm/tslib/tslib.js");

var tslib_1 = _interopRequireWildcard(_tslib);

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _index3 = require("../../npm/@tarojs/redux/index.js");

var _actions = require("../../store/actions.js");

var _user = require("../../apis/user.js");

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var enjoyTit = "/assets/img/enjoy/enjoy-tit.png";
var enjoyTit1 = "/assets/img/enjoy/e-tit1.png";
var enjoyTit2 = "/assets/img/enjoy/e-tit2.png";
var enjoyTit3 = "/assets/img/enjoy/e-tit3.png";
var enjoyBg = "/assets/img/enjoy/e-bg.png";
var enjoyLC = "/assets/img/enjoy/enjoy_lc.png";
var enjoyBtn = "/assets/img/enjoy/enjoy-btn.png";

var Activity = (_temp2 = _class = function (_BaseComponent) {
  _inherits(Activity, _BaseComponent);

  function Activity() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Activity);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Activity.__proto__ || Object.getPrototypeOf(Activity)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["anonymousState__temp", "shareInfo", "$compid__16", "enjoyTit", "enjoyTit1", "type", "enjoyBg", "enjoyBtn", "enjoyTit2", "enjoyLC", "enjoyTit3"], _this.config = {
      navigationBarTitleText: '邀请得现金'
    }, _this.customComponents = ["JTabBar"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Activity, [{
    key: "_constructor",
    value: function _constructor() {
      _get(Activity.prototype.__proto__ || Object.getPrototypeOf(Activity.prototype), "_constructor", this).apply(this, arguments);

      this.state = {
        shareInfo: {
          invite_reward: []
        }
      };
      this.$$refs = [];
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {}
  }, {
    key: "componentDidShow",
    value: function componentDidShow() {
      this.getInfo();
    }
  }, {
    key: "onShareTimeline",
    value: function onShareTimeline() {
      return {
        title: "分享有礼",
        path: '/pages/index/index?invite_user_id=' + this.state.shareInfo.invite_user_id,
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "getInfo",
    value: function getInfo() {
      var _this2 = this;

      _user2.default.InviteInfo().then(function (data) {
        _this2.setState({ shareInfo: data });
      });
    }
  }, {
    key: "showEnjoy",
    value: function showEnjoy() {
      console.log('showShareItems');
      // Taro.showShareMenu({
      //   withShareTicket: true,
      //   showShareItems: ['shareAppMessage', 'shareTimeline']
      // })
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "分享有礼",
        path: '/pages/index/index?invite_user_id=' + this.state.shareInfo.invite_user_id,
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__16 = (0, _index.genCompid)(__prefix + "$compid__16");

      var shareInfo = this.__state.shareInfo;
      // let count: number = 14
      var count = shareInfo.invite_number;
      var numArr = shareInfo.invite_reward.map(function (el) {
        return el.people_number;
      });

      var _numArr = _slicedToArray(numArr, 3),
          s = _numArr[0],
          m = _numArr[1],
          l = _numArr[2];

      var type = 0;
      var width = '0px';
      if (count >= s && count < m) {
        type = 1;
      } else if (count >= m && count < l) {
        type = 2;
      } else if (count >= l) {
        type = 3;
      }
      // 30  104 104 3
      if (count > 0 && count < s) {
        width = 30 / s * count + 'px';
      } else if (count >= s && count < m) {
        width = 30 + (count - s) * (104 / (m - s)) + 'px';
      } else if (count >= m && count < l) {
        width = 134 + (count - m) * (104 / (l - m)) + 'px';
      } else if (count >= l) {
        width = '100%';
      }
      var anonymousState__temp = (0, _index.internal_inline_style)({ width: width });
      _index.propsManager.set({
        "index": 2
      }, $compid__16);
      Object.assign(this.__state, {
        anonymousState__temp: anonymousState__temp,
        $compid__16: $compid__16,
        enjoyTit: enjoyTit,
        enjoyTit1: enjoyTit1,
        type: type,
        enjoyBg: enjoyBg,
        enjoyBtn: enjoyBtn,
        enjoyTit2: enjoyTit2,
        enjoyLC: enjoyLC,
        enjoyTit3: enjoyTit3
      });
      return this.__state;
    }
  }]);

  return Activity;
}(_index.Component), _class.$$events = ["showEnjoy"], _class.$$componentPath = "pages/activity/index", _temp2);
Activity = tslib_1.__decorate([(0, _index3.connect)(function (_ref2) {
  var reducer = _ref2.reducer;
  return {};
}, function (dispatch) {
  return {
    setTab: function setTab(num) {
      dispatch((0, _actions.SetTab)(num));
    }
  };
})], Activity);
exports.default = Activity;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(Activity, true));