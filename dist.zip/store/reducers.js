"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _redux = require("../npm/redux/lib/redux.js");

var _constants = require("./constants.js");

var INITIAL_STATE = {
  orderNum: '123456',
  countCar: 0,
  tab: 0,
  len: 0,
  goodsBuyingList: [],
  addrId: '',
  deliveryType: 2
};
var reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : INITIAL_STATE;
  var action = arguments[1];

  switch (action.type) {
    case _constants.ORDERNUM:
      return _extends({}, state, {
        orderNum: action.orderNum
      });
    case _constants.CARCOUNT:
      return _extends({}, state, {
        countCar: action.countCar
      });
    case _constants.TAB:
      return _extends({}, state, {
        tab: action.tab
      });
    case _constants.CAR_LEN:
      return _extends({}, state, {
        len: action.len
      });
    case _constants.GOODS_BUYING_LIST:
      return _extends({}, state, {
        goodsBuyingList: action.list
      });
    case _constants.ADDR_ID:
      return _extends({}, state, {
        addrId: action.id
      });
    case _constants.DELIVERY_TYPE:
      return _extends({}, state, {
        deliveryType: action.val
      });
    default:
      return state;
  }
};
exports.default = (0, _redux.combineReducers)({
  reducer: reducer
});