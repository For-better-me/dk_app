"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _tslib = require("../../npm/tslib/tslib.js");

var tslib_1 = _interopRequireWildcard(_tslib);

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _goods = require("../../apis/goods.js");

var _goods2 = _interopRequireDefault(_goods);

var _shoppingCar = require("../../apis/shoppingCar.js");

var _shoppingCar2 = _interopRequireDefault(_shoppingCar);

var _index3 = require("../../npm/@tarojs/redux/index.js");

var _actions = require("../../store/actions.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BtnEnjoy = "/assets/img/btn-enjoy.png";

var GoodsDetail = (_temp2 = _class = function (_BaseComponent) {
  _inherits(GoodsDetail, _BaseComponent);

  function GoodsDetail() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, GoodsDetail);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = GoodsDetail.__proto__ || Object.getPrototypeOf(GoodsDetail)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["goodsInfo", "$compid__39", "BtnEnjoy", "num", "setCountCar", "countCar"], _this.config = {
      navigationBarTitleText: '商品详情'
    }, _this.addShoppingCar = function () {
      if (_this.state.num == 0) {
        _index2.default.showToast({
          title: '添加数量不为0',
          icon: 'none',
          duration: 2000
        });
        return;
      }
      var data = {
        goods_id: _this.state.goodsInfo.id,
        goods_extend_id: _this.state.goodsInfo.goods_extend_list[0].goods_extend_id,
        number: _this.state.num
      };
      _shoppingCar2.default.shoppingCarAdd(data).then(function (res) {
        _this.props.setCountCar(_this.props.countCar + data.number);
        _index2.default.switchTab({ url: '/pages/shoppingCar/index' });
      });
    }, _this.shareEvent = function () {
      _index2.default.showShareMenu({
        withShareTicket: true,
        showShareItems: ['wechatFriends', 'wechatMoment']
      });
    }, _this.customComponents = ["JInputNumber"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(GoodsDetail, [{
    key: "_constructor",
    value: function _constructor() {
      _get(GoodsDetail.prototype.__proto__ || Object.getPrototypeOf(GoodsDetail.prototype), "_constructor", this).apply(this, arguments);

      this.state = {
        num: Number(this.$router.params.num),
        goodsInfo: null
      };
      this.$$refs = [];
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {}
  }, {
    key: "componentDidShow",
    value: function componentDidShow() {
      this.getDetail();
      if (!Number(this.$router.params.num) && this.$router.params.num != '0') {
        this.initNum();
      }
    }
  }, {
    key: "initNum",
    value: function initNum() {
      var _this2 = this;

      _shoppingCar2.default.shoppingCarList().then(function (res) {
        var goodsIDArr = res.goods_list.filter(function (el) {
          return el.goods_id == _this2.$router.params.id;
        });
        var num = 0;
        if (goodsIDArr.length > 0) {
          num = goodsIDArr[0].goods_cart_number;
        }
        _this2.setState({ num: num });
      });
    }
  }, {
    key: "getDetail",
    value: function getDetail() {
      var _this3 = this;

      var id = this.$router.params.id;
      _goods2.default.getGoodsInfo({ id: id }).then(function (data) {
        data.text = data.text.replace(/\<img/g, '<img style="width:100%;height:auto;display:block"');
        _this3.setState({ goodsInfo: data });
      });
    }
  }, {
    key: "changeNumber",
    value: function changeNumber(num) {
      this.setState({ num: num });
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: this.state.goodsInfo.title || '每味十足',
        path: '/pages/goodsDetail/index?id=' + this.$router.params.id,
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__39 = (0, _index.genCompid)(__prefix + "$compid__39");

      var goodsInfo = this.__state.goodsInfo;

      goodsInfo && _index.propsManager.set({
        "value": this.__state.num,
        "isHidden": false,
        "changeNumber": this.changeNumber.bind(this)
      }, $compid__39);
      Object.assign(this.__state, {
        $compid__39: $compid__39,
        BtnEnjoy: BtnEnjoy
      });
      return this.__state;
    }
  }]);

  return GoodsDetail;
}(_index.Component), _class.$$events = ["shareEvent", "addShoppingCar"], _class.$$componentPath = "pages/goodsDetail/index", _temp2);
GoodsDetail = tslib_1.__decorate([(0, _index3.connect)(function (_ref2) {
  var reducer = _ref2.reducer;
  return {
    countCar: reducer.countCar
  };
}, function (dispatch) {
  return {
    setCountCar: function setCountCar(num) {
      dispatch((0, _actions.SetCountCar)(num));
    }
  };
})], GoodsDetail);
exports.default = GoodsDetail;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(GoodsDetail, true));