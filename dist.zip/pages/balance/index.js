"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _user = require("../../apis/user.js");

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BgBalance = "/assets/img/bg-ye.png";

var Balance = (_temp2 = _class = function (_BaseComponent) {
  _inherits(Balance, _BaseComponent);

  function Balance() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Balance);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Balance.__proto__ || Object.getPrototypeOf(Balance)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["BgBalance", "choosedId", "rechargeList", "balance", "rechargeDesc"], _this.config = {
      navigationBarTitleText: '余额充值'
    }, _this.moreLog = function () {
      _index2.default.navigateTo({
        url: '/pages/balanceList/index'
      });
    }, _this.rechargeEvent = function () {
      if (!_this.state.choosedId) {
        _index2.default.showToast({
          title: '请选择你要充值的数额',
          icon: 'none'
        });
        return;
      }
      var data = { id: _this.state.choosedId };
      _index2.default.showLoading({
        title: '加载中',
        mask: true
      });
      _user2.default.rechargePay(data).then(function (res) {
        _index2.default.requestPayment(_extends({}, res, {
          success: function success() {
            this.getBalance();
            _index2.default.hideLoading();
            _index2.default.showToast({ title: '支付成功' });
          },
          fail: function fail() {
            _index2.default.hideLoading();
            _index2.default.showToast({ title: '支付失败', icon: 'none' });
          }
        }));
      });
    }, _this.customComponents = [], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Balance, [{
    key: "_constructor",
    value: function _constructor() {
      _get(Balance.prototype.__proto__ || Object.getPrototypeOf(Balance.prototype), "_constructor", this).apply(this, arguments);

      this.state = {
        balance: '--',
        rechargeList: [],
        choosedId: '',
        rechargeDesc: ''
      };
      this.$$refs = [];
    }
  }, {
    key: "getBalance",
    value: function getBalance() {
      var _this2 = this;

      _user2.default.recharge().then(function (data) {
        _this2.setState({
          balance: data.balance,
          rechargeList: data.recharge_list,
          rechargeDesc: data.recharge_desc
        });
      });
    }
  }, {
    key: "componentWillMount",
    value: function componentWillMount() {
      this.getBalance();
    }
  }, {
    key: "selectRecharge",
    value: function selectRecharge(choosedId) {
      this.setState({
        choosedId: choosedId
      });
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;

      var _state = this.__state,
          balance = _state.balance,
          choosedId = _state.choosedId;

      var rechargeList = this.__state.rechargeList;
      Object.assign(this.__state, {
        BgBalance: BgBalance
      });
      return this.__state;
    }
  }]);

  return Balance;
}(_index.Component), _class.$$events = ["moreLog", "selectRecharge", "rechargeEvent"], _class.$$componentPath = "pages/balance/index", _temp2);
exports.default = Balance;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(Balance, true));