"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _index = require("./npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _index3 = require("./npm/@tarojs/redux/index.js");

var _index4 = require("./store/index.js");

var _index5 = _interopRequireDefault(_index4);

var _shoppingCar = require("./apis/shoppingCar.js");

var _shoppingCar2 = _interopRequireDefault(_shoppingCar);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
// import Index from './pages/index'

var store = (0, _index5.default)();
(0, _index3.setStore)(store);

if (_index3.ReduxContext.Provider) {
  _index3.ReduxContext.Provider({
    store: store
  });
  _index3.ReduxContext.Provider({
    store: store
  });
}

var _App = function (_BaseComponent) {
  _inherits(_App, _BaseComponent);

  function _App() {
    _classCallCheck(this, _App);

    /**
     * 指定config的类型声明为: Taro.Config
     *
     * 由于 typescript 对于 object 类型推导只能推出 Key 的基本类型
     * 对于像 navigationBarTextStyle: 'black' 这样的推导出的类型是 string
     * 提示和声明 navigationBarTextStyle: 'black' | 'white' 类型冲突, 需要显示声明类型
     */
    var _this = _possibleConstructorReturn(this, (_App.__proto__ || Object.getPrototypeOf(_App)).apply(this, arguments));

    _this.config = {
      "permission": {
        "scope.userLocation": {
          "desc": "请确认授权"
        }
      },
      pages: ['pages/index/index', 'pages/address/index', 'pages/search/index', 'pages/couponList/index', 'pages/activity/index', 'pages/login/index', 'pages/mine/index', 'pages/aboutUs/index', 'pages/submitOrder/index', 'pages/integralList/index', 'pages/shoppingCar/index', 'pages/goodsDetail/index', 'pages/integral/index', 'pages/balanceList/index', 'pages/balance/index', 'pages/orderDetail/index', 'pages/orderMy/index', 'pages/pay/index', 'pages/addressEdit/index'],
      window: {
        backgroundTextStyle: 'light',
        navigationBarBackgroundColor: '#fff',
        navigationBarTitleText: '每味十足',
        navigationBarTextStyle: 'black'
      },
      tabBar: {
        "backgroundColor": "#fff",
        "borderStyle": "black",
        "selectedColor": "#10E6AC",
        "color": "#333",
        "list": [{
          "pagePath": "pages/index/index",
          "iconPath": "./assets/img/icon-index.png",
          "selectedIconPath": "./assets/img/icon-index.png",
          "text": "首页"
        }, {
          "pagePath": "pages/shoppingCar/index",
          "iconPath": "./assets/img/icon-car.png",
          "selectedIconPath": "./assets/img/icon-car.png",
          "text": "购物车"
        }, {
          "pagePath": "pages/activity/index",
          "iconPath": "./assets/img/icon-activity.png",
          "selectedIconPath": "./assets/img/icon-activity.png",
          "text": "活动"
        }, {
          "pagePath": "pages/mine/index",
          "iconPath": "./assets/img/icon-mine.png",
          "selectedIconPath": "./assets/img/icon-mine.png",
          "text": "我的"
        }]
      }
    };
    return _this;
  }

  _createClass(_App, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      console.log('app is componentWillMount');
      _index2.default.hideTabBar();
    }
  }, {
    key: "componentDidShow",
    value: function componentDidShow() {
      console.log('app is componentDidShow');
      _index2.default.hideTabBar();
      if (!_index2.default.getStorageSync('token')) {
        _index2.default.navigateTo({ url: '/pages/login/index' });
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      console.log('app is componentDidMount');
      this.getCarLen();
    }
  }, {
    key: "getCarLen",
    value: function getCarLen() {
      _shoppingCar2.default.shoppingCarList().then(function (data) {
        store.dispatch({
          type: 'CARCOUNT',
          countCar: data.goods_list.length
        });
      });
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      console.log('componentWillUnmount');
    }
  }, {
    key: "componentDidHide",
    value: function componentDidHide() {
      console.log('componentDidHide');
    }
  }, {
    key: "componentDidCatchError",
    value: function componentDidCatchError() {
      console.log('componentDidCatchError');
    }
    // 在 App 类中的 render() 函数没有实际作用
    // 请勿修改此函数

  }, {
    key: "_createData",
    value: function _createData() {}
  }]);

  return _App;
}(_index.Component);

exports.default = _App;

App(require('./npm/@tarojs/taro-weapp/index.js').default.createApp(_App));
_index2.default.initPxTransform({
  "designWidth": 750,
  "deviceRatio": {
    "640": 1.17,
    "750": 1,
    "828": 0.905
  }
});