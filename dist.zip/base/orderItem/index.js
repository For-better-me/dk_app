"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _order = require("../../apis/order.js");

var _order2 = _interopRequireDefault(_order);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ImageCancel = "/assets/img/bg-cancel.png";
var ImageIng = "/assets/img/bg-ordering.png";
var ImageUnPay = "/assets/img/bg-unpay.png";
var ImageOver = "/assets/img/bg-over.png";

var OrderItem = (_temp2 = _class = function (_BaseComponent) {
  _inherits(OrderItem, _BaseComponent);

  function OrderItem() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, OrderItem);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = OrderItem.__proto__ || Object.getPrototypeOf(OrderItem)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["anonymousState__temp", "anonymousState__temp2", "orderInfo", "payPrice"], _this.customComponents = [], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(OrderItem, [{
    key: "_constructor",
    value: function _constructor(props) {
      _get(OrderItem.prototype.__proto__ || Object.getPrototypeOf(OrderItem.prototype), "_constructor", this).call(this, props);

      this.$$refs = [];
    }
  }, {
    key: "navTo",
    value: function navTo(url) {
      _index2.default.navigateTo({ url: url });
    }
  }, {
    key: "typeText",
    value: function typeText(type) {
      var typeText = '';
      var img = '';
      switch (type) {
        case 10:
          typeText = '待支付';
          img = ImageUnPay;
          break;
        case 20:
          typeText = '已支付';
          img = ImageIng;
          break;
        case 30:
          typeText = '已取消';
          img = ImageCancel;
          break;
        case 40:
          typeText = '已发货';
          img = ImageIng;
          break;
        case 50:
          typeText = '已收货';
          img = ImageOver;
          break;
        case 60:
          typeText = '已完成';
          img = ImageOver;
          break;
        default:
          break;
      }
      return { typeText: typeText, img: img };
    }
  }, {
    key: "orderCancel",
    value: function orderCancel(order_id) {
      var self = this;
      _index2.default.showModal({
        title: '温馨提示',
        content: '确定要取消该订单吗？',
        success: function success(res) {
          if (res.confirm) {
            _order2.default.orderCancel({ order_id: order_id }).then(function (res) {
              self.props.eventListener(order_id, 30);
              _index2.default.showToast({ title: '取消成功' });
            });
          } else if (res.cancel) {
            console.log('用户点击取消');
          }
        }
      });
    }
  }, {
    key: "orderDel",
    value: function orderDel(order_id) {
      var self = this;
      _index2.default.showModal({
        title: '温馨提示',
        content: '确定要删除该订单吗？',
        success: function success(res) {
          if (res.confirm) {
            _order2.default.orderDel({ order_id: order_id }).then(function (res) {
              self.props.eventListener(order_id, 0);
              _index2.default.showToast({ title: '删除成功' });
            });
          } else if (res.cancel) {
            console.log('用户点击取消');
          }
        }
      });
    }
  }, {
    key: "orderPay",
    value: function orderPay(sn, price) {
      _index2.default.navigateTo({
        url: '/pages/pay/index?sn=' + sn + '&&price=' + price
      });
    }
  }, {
    key: "orderDetail",
    value: function orderDetail(id) {
      _index2.default.navigateTo({
        url: '/pages/orderDetail/index?id=' + id
      });
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;

      var _props = _extends({}, this.__props),
          orderInfo = _props.orderInfo;

      var payPrice = (Number(orderInfo.total_price * 1000) + Number(orderInfo.freight * 1000)) / 1000;
      var anonymousState__temp = this.typeText(orderInfo.status).img;
      var anonymousState__temp2 = this.typeText(orderInfo.status).typeText;
      Object.assign(this.__state, {
        anonymousState__temp: anonymousState__temp,
        anonymousState__temp2: anonymousState__temp2,
        orderInfo: orderInfo,
        payPrice: payPrice
      });
      return this.__state;
    }
  }]);

  return OrderItem;
}(_index.Component), _class.$$events = ["orderDetail", "orderDel", "orderCancel", "orderPay"], _class.$$componentPath = "base/orderItem/index", _temp2);

OrderItem.defaultProps = {
  orderInfo: {
    total_price: 0
  }
};
exports.default = OrderItem;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(OrderItem));