'use strict';

{
  module.exports = require('./cjs/react-is.development.js');
}