"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _tslib = require("../../npm/tslib/tslib.js");

var tslib_1 = _interopRequireWildcard(_tslib);

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _index3 = require("../../npm/@tarojs/redux/index.js");

var _actions = require("../../store/actions.js");

var _goods = require("../../apis/goods.js");

var _goods2 = _interopRequireDefault(_goods);

var _shoppingCar = require("../../apis/shoppingCar.js");

var _shoppingCar2 = _interopRequireDefault(_shoppingCar);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Search = (_temp2 = _class = function (_BaseComponent) {
  _inherits(Search, _BaseComponent);

  function Search() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Search);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Search.__proto__ || Object.getPrototypeOf(Search)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["loopArray5", "$compid__11", "$compid__12", "$compid__13", "goodsList", "keyWords", "countCar", "setCountCar"], _this.config = {
      navigationBarTitleText: '搜索'
    }, _this.changeNumber = function (num, extra, type, event) {
      event.stopPropagation();
      var countCar = _this.props.countCar;

      var _extra = _slicedToArray(extra, 3),
          i = _extra[0],
          j = _extra[1],
          goodsCarId = _extra[2];

      var goodsList = _this.state.goodsList;
      if (num == 0 && type == 'sub') {
        var data = {
          ids: [goodsCarId]
        };
        _shoppingCar2.default.shoppingCarDel(data).then(function (res) {
          _this.props.setCountCar(countCar - 1);
          _this.getCarList(goodsList);
        });
      } else if (num == 1 && type == 'add') {
        var _data = {
          goods_id: goodsList[i].id,
          goods_extend_id: goodsList[i].goods_extend_list[0].goods_extend_id,
          number: num
        };
        _shoppingCar2.default.shoppingCarAdd(_data).then(function (res) {
          _this.props.setCountCar(countCar + 1);
          _this.getCarList(goodsList);
        });
      } else {
        var _data2 = {
          id: goodsCarId,
          type: type == 'add' ? 1 : 2
        };
        _shoppingCar2.default.shoppingCountUpdate(_data2).then(function (res) {
          _this.getCarList(goodsList);
        });
      }
    }, _this.customComponents = ["AtIcon", "AtInput", "NoData", "JInputNumber"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Search, [{
    key: "_constructor",
    value: function _constructor() {
      _get(Search.prototype.__proto__ || Object.getPrototypeOf(Search.prototype), "_constructor", this).apply(this, arguments);

      this.state = {
        goodsList: [],
        keyWords: ''
      };
      this.$$refs = [];
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {}
  }, {
    key: "getList",
    value: function getList(keyword) {
      var _this2 = this;

      _goods2.default.getSearchGoods({ keyword: keyword }).then(function (data) {
        _this2.getCarList(data);
        _this2.setState({
          goodsList: data
        });
      });
    }
  }, {
    key: "getCarList",
    value: function getCarList(goodsData) {
      var _this3 = this;

      if (goodsData.length == 0) {
        return;
      }
      _shoppingCar2.default.shoppingCarList().then(function (data) {
        if (data.goods_list.length == 0) {
          goodsData = goodsData.map(function (goods) {
            goods.goods_extend_list = goods.goods_extend_list.map(function (goodsExtend) {
              goodsExtend.count = 0;
              return goodsExtend;
            });
            return goods;
          });
        } else {
          goodsData = goodsData.map(function (goodsItem) {
            goodsItem.goods_extend_list = goodsItem.goods_extend_list.map(function (goodsExtend) {
              for (var i = 0; i < data.goods_list.length; i++) {
                var el = data.goods_list[i];
                if (el.goods_id == goodsItem.id && el.goods_extend_id == goodsExtend.goods_extend_id) {
                  goodsExtend.count = el.goods_cart_number;
                  goodsExtend.carId = el.id;
                  break;
                } else {
                  goodsExtend.count = 0;
                  goodsExtend.carId = null;
                }
              }
              return goodsExtend;
            });
            return goodsItem;
          });
        }
        _this3.setState({
          goodsList: goodsData
        });
      });
    }
  }, {
    key: "navTo",
    value: function navTo(id, num) {}
  }, {
    key: "handleChange",
    value: function handleChange(e) {
      this.getList(e);
      this.setState({
        keyWords: e
      });
    }
  }, {
    key: "cancel",
    value: function cancel() {
      _index2.default.navigateBack();
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      var _this4 = this;

      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__11 = (0, _index.genCompid)(__prefix + "$compid__11");
      var $compid__12 = (0, _index.genCompid)(__prefix + "$compid__12");
      var $compid__13 = (0, _index.genCompid)(__prefix + "$compid__13");

      var loopArray5 = this.__state.goodsList.map(function (goods, index) {
        goods = {
          $original: (0, _index.internal_get_original)(goods)
        };
        var $loopState__temp2 = index + '_' + goods.$original.id;
        var $loopState__temp4 = [index, 0, goods.$original.goods_extend_list[0].carId];
        var $compid__10 = (0, _index.genCompid)(__prefix + "YmyHaFxbGR" + index);
        _index.propsManager.set({
          "value": goods.$original.goods_extend_list[0].count,
          "isHidden": true,
          "extra": $loopState__temp4,
          "changeNumber": _this4.changeNumber
        }, $compid__10);
        return {
          $loopState__temp2: $loopState__temp2,
          $loopState__temp4: $loopState__temp4,
          $compid__10: $compid__10,
          $original: goods.$original
        };
      });

      _index.propsManager.set({
        "value": "search",
        "size": "16",
        "color": "#666"
      }, $compid__11);
      _index.propsManager.set({
        "autoFocus": true,
        "name": "search",
        "type": "text",
        "placeholder": "\u8BF7\u8F93\u5165\u5546\u54C1\u540D\u79F0",
        "onChange": this.handleChange.bind(this)
      }, $compid__12);
      this.__state.goodsList.length == 0 && this.__state.keyWords != '' && _index.propsManager.set({
        "tip": "\u6CA1\u6709\u76F8\u5173\u5546\u54C1"
      }, $compid__13);
      Object.assign(this.__state, {
        loopArray5: loopArray5,
        $compid__11: $compid__11,
        $compid__12: $compid__12,
        $compid__13: $compid__13
      });
      return this.__state;
    }
  }]);

  return Search;
}(_index.Component), _class.$$events = ["cancel", "navTo"], _class.$$componentPath = "pages/search/index", _temp2);
Search = tslib_1.__decorate([(0, _index3.connect)(function (_ref2) {
  var reducer = _ref2.reducer;
  return {
    countCar: reducer.countCar
  };
}, function (dispatch) {
  return {
    setCountCar: function setCountCar(num) {
      dispatch((0, _actions.SetCountCar)(num));
    }
  };
})], Search);
exports.default = Search;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(Search, true));