'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _http2 = require('../utils/http.js');

var _http3 = _interopRequireDefault(_http2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var OrderApi = function () {
  function OrderApi() {
    _classCallCheck(this, OrderApi);
  }

  _createClass(OrderApi, null, [{
    key: 'getSubmitInfo',
    value: function getSubmitInfo(data) {
      return (0, _http3.default)({
        url: '/api/order/cartOrderGoodsList',
        data: data,
        loading: false
      });
    }
  }, {
    key: 'submitOrder',
    value: function submitOrder(data) {
      return (0, _http3.default)({
        url: '/api/order/cartCreateOrder',
        data: data
      });
    }
  }, {
    key: 'addrList',
    value: function addrList(data) {
      return (0, _http3.default)({
        url: '/api/Collectaddress/getList',
        data: data
      });
    }
  }, {
    key: 'updateCollectStatus',
    value: function updateCollectStatus(data) {
      return (0, _http3.default)({
        url: '/api/Collectaddress/updateCollectStatus',
        data: data
      });
    }
  }, {
    key: 'addrDel',
    value: function addrDel(data) {
      return (0, _http3.default)({
        url: '/api/Collectaddress/delInfo',
        data: data
      });
    }
  }, {
    key: 'addrInfo',
    value: function addrInfo(data) {
      return (0, _http3.default)({
        url: '/api/Collectaddress/getInfo',
        data: data
      });
    }
  }, {
    key: 'addrUpdate',
    value: function addrUpdate(data) {
      return (0, _http3.default)({
        url: '/api/Collectaddress/updateInfo',
        data: data
      });
    }
  }, {
    key: 'addrNew',
    value: function addrNew(data) {
      return (0, _http3.default)({
        url: '/api/Collectaddress/addInfo',
        data: data
      });
    }
  }, {
    key: 'orderList',
    value: function orderList(data) {
      return (0, _http3.default)({
        url: '/api/order/getOrderlist',
        data: data
      });
    }
  }, {
    key: 'orderCancel',
    value: function orderCancel(data) {
      return (0, _http3.default)({
        url: '/api/order/cancelOrder',
        data: data
      });
    }
  }, {
    key: 'orderDel',
    value: function orderDel(data) {
      return (0, _http3.default)({
        url: '/api/order/delInfo',
        data: data
      });
    }
  }, {
    key: 'orderInfo',
    value: function orderInfo(data) {
      return (0, _http3.default)({
        url: '/api/order/getOrderInfo',
        data: data
      });
    }
  }, {
    key: 'orderPay',
    value: function orderPay(data) {
      return (0, _http3.default)({
        url: '/api/order/goPayment',
        data: data
      });
    }
  }]);

  return OrderApi;
}();

exports.default = OrderApi;