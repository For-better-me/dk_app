'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = require('../npm/@tarojs/taro-weapp/index.js');

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _http = function _http(opt) {
  var _promise = new Promise(function (resolve, reject) {
    var defaultOpt = {
      loading: true,
      method: 'POST',
      data: {},
      header: {
        token: _index2.default.getStorageSync('token') ? _index2.default.getStorageSync('token') : ''
      }
    };
    // 合并
    opt = Object.assign({}, defaultOpt, opt);
    opt.url = 'https://www.tjitfw.com' + opt.url;
    var loading = opt.loading; // 是否显示加载提示弹窗
    _index2.default.request({
      url: opt.url,
      method: opt.method,
      data: opt.data,
      header: opt.header,
      success: function success(res) {
        if (res.data.code == 1001) {
          reject({
            code: 1001,
            msg: opt.url + '接口需要token参数3，但系统中不存在token'
          });
        } else if (res.data.code == 0) {
          _index2.default.hideLoading();
          resolve(res.data.data);
          console.log('请求成功', opt.url, res.data);
        } else {
          _index2.default.hideLoading();
          reject(res.data);
        }
      },
      fail: function fail(res) {
        reject(res);
        console.log(opt.url, '通信接口失败');
      }
    });
    if (loading) {
      _index2.default.showLoading({
        title: '加载中',
        mask: true
      });
    }
  });
  return _promise.catch(function (err) {
    _index2.default.hideLoading();
    if (err.code == 1001) {
      _index2.default.hideLoading();
      console.log('err1001', err.msg);
      _index2.default.setStorageSync('token', '');
      // Taro.navigateTo({ url: '/pages/login/index' })
    } else if (err.code == -1) {
      _index2.default.showToast({
        title: err.msg,
        icon: 'none',
        duration: 2000
      });
      console.log('非err1001', err.msg, opt.url);
    }
    return Promise.reject({
      code: err.code,
      msg: err.msg
    });
  });
};
exports.default = _http;