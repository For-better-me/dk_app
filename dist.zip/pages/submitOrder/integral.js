"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var IntegralComp = (_temp2 = _class = function (_BaseComponent) {
  _inherits(IntegralComp, _BaseComponent);

  function IntegralComp() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, IntegralComp);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = IntegralComp.__proto__ || Object.getPrototypeOf(IntegralComp)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["$compid__48", "integralInfo", "integral", "price", "integralNum", "change"], _this.changeIngetral = function (num) {
      var integralInfo = _this.props.integralInfo;
      var integral = num * integralInfo.integral_scale;
      var price = integral / integralInfo.integral_use_price;
      _this.props.change(num, price, integral);
    }, _this.customComponents = ["JInputNumber"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(IntegralComp, [{
    key: "_constructor",
    value: function _constructor(props) {
      _get(IntegralComp.prototype.__proto__ || Object.getPrototypeOf(IntegralComp.prototype), "_constructor", this).call(this, props);
      this.state = {
        // integral: 0,
        // price: 0,
        // value: 0
      };
      this.$$refs = [];
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__48 = (0, _index.genCompid)(__prefix + "$compid__48");

      var integralInfo = this.__props.integralInfo;
      var num = this.__props.integralNum;
      var integral = num * integralInfo.integral_scale;
      var price = integral / integralInfo.integral_use_price;
      var min = 0;
      var max = Math.floor(integralInfo.max_current_integral / integralInfo.integral_scale);
      console.log(max);
      _index.propsManager.set({
        "min": min,
        "max": max,
        "value": num,
        "changeNumber": this.changeIngetral
      }, $compid__48);
      Object.assign(this.__state, {
        $compid__48: $compid__48,
        integralInfo: integralInfo,
        integral: integral,
        price: price
      });
      return this.__state;
    }
  }]);

  return IntegralComp;
}(_index.Component), _class.$$events = [], _class.$$componentPath = "pages/submitOrder/integral", _temp2);

IntegralComp.defaultProps = {
  integralInfo: {
    max_current_integral: 0,
    integral_scale: 100
  }
};
exports.default = IntegralComp;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(IntegralComp));