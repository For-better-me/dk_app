'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _http2 = require('../utils/http.js');

var _http3 = _interopRequireDefault(_http2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var GoodsApi = function () {
  function GoodsApi() {
    _classCallCheck(this, GoodsApi);
  }

  _createClass(GoodsApi, null, [{
    key: 'getShop',
    value: function getShop() {
      return (0, _http3.default)({
        url: '/api/shop/info'
      });
    }
  }, {
    key: 'getGoodsInfo',
    value: function getGoodsInfo(data) {
      return (0, _http3.default)({
        url: '/api/goods/getInfo',
        data: data
      });
    }
  }, {
    key: 'getSearchGoods',
    value: function getSearchGoods(data) {
      return (0, _http3.default)({
        url: '/api/Goods/getList',
        data: data
      });
    }
  }, {
    key: 'getFocusList',
    value: function getFocusList() {
      return (0, _http3.default)({
        url: '/api/shop/getFocusList'
      });
    }
  }, {
    key: 'getShopInfo',
    value: function getShopInfo(data) {
      return (0, _http3.default)({
        url: '/api/shop/getShopInfo',
        data: data
      });
    }
  }]);

  return GoodsApi;
}();

exports.default = GoodsApi;