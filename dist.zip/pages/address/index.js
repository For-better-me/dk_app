"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _tslib = require("../../npm/tslib/tslib.js");

var tslib_1 = _interopRequireWildcard(_tslib);

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

var _order = require("../../apis/order.js");

var _order2 = _interopRequireDefault(_order);

var _index3 = require("../../npm/@tarojs/redux/index.js");

var _actions = require("../../store/actions.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Address = (_temp2 = _class = function (_BaseComponent) {
  _inherits(Address, _BaseComponent);

  function Address() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, Address);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Address.__proto__ || Object.getPrototypeOf(Address)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["loopArray4", "$compid__8", "$compid__9", "addressList", "addrId", "setAddrId"], _this.config = {
      navigationBarTitleText: '收货地址'
    }, _this.newAddr = function (id) {
      _index2.default.navigateTo({
        url: '/pages/addressEdit/index?id=' + id
      });
    }, _this.updateDefault = function (val, _ref2) {
      var _ref3 = _slicedToArray(_ref2, 2),
          id = _ref3[0],
          is_default = _ref3[1];

      if (is_default == 2) {
        return;
      }
      _order2.default.updateCollectStatus({ id: id }).then(function (res) {
        var list = _this.state.addressList.map(function (el) {
          if (el.id == id) {
            el.is_default = 2;
          } else {
            el.is_default = 1;
          }
          return el;
        });
        _this.setState({ addressList: list });
      });
    }, _this.setAddrIdHandle = function (id) {
      if (_this.$router.params.flag == '1') {
        _index2.default.navigateBack();
        _this.props.setAddrId(id);
      }
    }, _this.customComponents = ["CheckboxJ", "AtIcon", "NoData"], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(Address, [{
    key: "_constructor",
    value: function _constructor(props) {
      _get(Address.prototype.__proto__ || Object.getPrototypeOf(Address.prototype), "_constructor", this).call(this, props);

      this.limit = 5;
      this.page = 1;
      this.total = 0;

      this.state = {
        addressList: []
      };
      this.$$refs = [];
    }
  }, {
    key: "componentDidShow",
    value: function componentDidShow() {
      this.init();
    }
  }, {
    key: "init",
    value: function init() {
      var _this2 = this;

      var data = { limit: this.limit, page: this.page };
      _order2.default.addrList(data).then(function (res) {
        var addressList = res.list;
        _this2.total = res.total_page;
        _this2.setState({ addressList: addressList });
      });
    }
  }, {
    key: "initMore",
    value: function initMore() {
      var _this3 = this;

      var data = { limit: this.limit, page: this.page };
      _order2.default.addrList(data).then(function (res) {
        var addressList = _this3.state.addressList.concat(res.list);
        _this3.total = res.total_page;
        _this3.setState({ addressList: addressList });
      });
    }
  }, {
    key: "delAddrTip",
    value: function delAddrTip() {
      return new Promise(function (resolve, reject) {
        _index2.default.showModal({
          title: '温馨提示',
          content: '确定要删除该地址吗？',
          success: function success(res) {
            if (res.confirm) {
              resolve();
            } else if (res.cancel) {
              console.log('用户点击取消');
            }
          }
        });
      });
    }
  }, {
    key: "delAddr",
    value: function delAddr(id) {
      var _this4 = this;

      this.delAddrTip().then(function () {
        _order2.default.addrDel({ id: id }).then(function (res) {
          _this4.init();
          _index2.default.showToast({
            title: '删除成功'
          });
          if (_this4.props.addrId == id) {
            console.log(33);
            _this4.props.setAddrId('');
          }
        });
      });
    }
  }, {
    key: "onReachBottom",
    value: function onReachBottom() {
      var page = this.page++;
      if (page > this.total) {
        _index2.default.showToast({
          title: '没有更多了',
          icon: 'none'
        });
        return;
      }
      this.initMore();
    }
  }, {
    key: "onShareAppMessage",
    value: function onShareAppMessage() {
      return {
        title: "每味十足",
        path: '/pages/index/index',
        imageUrl: '' // 图片路径
      };
    }
  }, {
    key: "_createData",
    value: function _createData() {
      var _this5 = this;

      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;
      var $compid__8 = (0, _index.genCompid)(__prefix + "$compid__8");
      var $compid__9 = (0, _index.genCompid)(__prefix + "$compid__9");

      var addressList = this.__state.addressList;
      var loopArray4 = addressList.length > 0 ? addressList.map(function (el, _anonIdx) {
        el = {
          $original: (0, _index.internal_get_original)(el)
        };
        var $loopState__temp2 = addressList.length > 0 ? el.$original.is_default == 2 : null;
        var $loopState__temp4 = addressList.length > 0 ? [el.$original.id, el.$original.is_default] : null;
        var $compid__5 = (0, _index.genCompid)(__prefix + "PQSFhaoPRn" + _anonIdx);
        _index.propsManager.set({
          "value": $loopState__temp2,
          "extra": $loopState__temp4,
          "change": _this5.updateDefault
        }, $compid__5);
        var $compid__6 = (0, _index.genCompid)(__prefix + "hyQJCtcqBv" + _anonIdx);
        _index.propsManager.set({
          "value": "edit",
          "size": "14",
          "color": "#8A857C"
        }, $compid__6);
        var $compid__7 = (0, _index.genCompid)(__prefix + "FKQDkFZLFu" + _anonIdx);
        _index.propsManager.set({
          "value": "trash",
          "size": "14",
          "color": "#8A857C"
        }, $compid__7);
        return {
          $loopState__temp2: $loopState__temp2,
          $loopState__temp4: $loopState__temp4,
          $compid__5: $compid__5,
          $compid__6: $compid__6,
          $compid__7: $compid__7,
          $original: el.$original
        };
      }) : [];
      _index.propsManager.set({
        "tip": "\u5BA2\u5B98\u8FD8\u6CA1\u6709\u521B\u5EFA\u5730\u5740\u54E6"
      }, $compid__8);
      _index.propsManager.set({
        "value": "add-circle",
        "size": "20",
        "color": "#fff"
      }, $compid__9);
      Object.assign(this.__state, {
        loopArray4: loopArray4,
        $compid__8: $compid__8,
        $compid__9: $compid__9
      });
      return this.__state;
    }
  }]);

  return Address;
}(_index.Component), _class.$$events = ["setAddrIdHandle", "newAddr", "delAddr"], _class.$$componentPath = "pages/address/index", _temp2);
Address = tslib_1.__decorate([(0, _index3.connect)(function (_ref4) {
  var reducer = _ref4.reducer;
  return {
    addrId: reducer.addrId
  };
}, function (dispatch) {
  return {
    setAddrId: function setAddrId(id) {
      dispatch((0, _actions.SetAddrId)(id));
    }
  };
})], Address);
exports.default = Address;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(Address, true));