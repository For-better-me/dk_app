"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _order = require("../apis/order.js");

var _order2 = _interopRequireDefault(_order);

var _index = require("../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function formatNumber(n) {
  var str = n.toString();
  return str[1] ? str : "0" + str;
}
function formatTime(date) {
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  var t1 = [year, month, day].map(formatNumber).join('/');
  var t2 = [hour, minute, second].map(formatNumber).join(':');
  return t1 + " " + t2;
}
function formatDate(date) {
  var mark = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '-';

  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var t1 = [year, month, day].map(formatNumber).join(mark);
  return "" + t1;
}
function isTel(tel) {
  var reg = /^1[2|3|4|5|6|7|8|9]\d{9}$/;
  if (reg.test(tel)) {
    return true;
  } else {
    return false;
  }
}
//深拷贝
function deepClone(obj) {
  var _obj = JSON.stringify(obj),
      objClone = JSON.parse(_obj);
  return objClone;
}
function findIndex(ary, fn) {
  if (ary.findIndex) {
    return ary.findIndex(fn);
  }
  var index = -1;
  ary.some(function (item, i, ary) {
    var ret = fn(item, i, ary);
    if (ret) {
      index = i;
      return ret;
    }
  });
  return index;
}
// 将url后的参数组合成对象并返回
function urlParams(url) {
  url = url ? url : window.location.href.split("#")[0];
  var queryStringUrl = url.slice(url.indexOf("?") + 1);
  var urlParamsObj = qs.parse(queryStringUrl, { ignoreQueryPrefix: true });
  return urlParamsObj;
}
function orderPay(sn, payment_model) {
  _index2.default.showLoading({
    title: '加载中',
    mask: true
  });
  var data = { sn: sn, payment_model: payment_model };
  return new Promise(function (resolve, reject) {
    _order2.default.orderPay(data).then(function (res) {
      _index2.default.requestPayment(_extends({}, res, {
        success: function success() {
          _index2.default.hideLoading();
          _index2.default.redirectTo({ url: '/pages/orderMy/index' });
          _index2.default.showToast({ title: '支付成功' });
          resolve();
        },
        fail: function fail() {
          _index2.default.hideLoading();
          _index2.default.showToast({ title: '支付失败', icon: 'none' });
          reject();
        }
      }));
    });
  });
}
function formatDuration(time) {
  var arr = time.split(':');
  var duration = parseInt(arr[0]) * 60 + parseInt(arr[1]);
  return duration;
}
exports.default = {
  formatNumber: formatNumber,
  formatTime: formatTime,
  formatDate: formatDate,
  isTel: isTel,
  deepClone: deepClone,
  findIndex: findIndex,
  urlParams: urlParams,
  orderPay: orderPay,
  formatDuration: formatDuration
};