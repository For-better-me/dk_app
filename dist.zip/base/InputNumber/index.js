"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _class, _temp2;

var _index = require("../../npm/@tarojs/taro-weapp/index.js");

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var IconSub = "/assets/img/icon_sub.png";
var IconAdd = "/assets/img/icon_add.png";

var InputNumber = (_temp2 = _class = function (_BaseComponent) {
  _inherits(InputNumber, _BaseComponent);

  function InputNumber() {
    var _ref;

    var _temp, _this, _ret;

    _classCallCheck(this, InputNumber);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = InputNumber.__proto__ || Object.getPrototypeOf(InputNumber)).call.apply(_ref, [this].concat(args))), _this), _this.$usedState = ["flag", "IconSub", "IconAdd", "value", "changeNumber"], _this.sub = function (event) {
      var _this$props = _extends({}, _this.props),
          _this$props$isZero = _this$props.isZero,
          isZero = _this$props$isZero === undefined ? true : _this$props$isZero,
          _this$props$value = _this$props.value,
          value = _this$props$value === undefined ? 0 : _this$props$value,
          _this$props$min = _this$props.min,
          min = _this$props$min === undefined ? 1 : _this$props$min,
          extra = _this$props.extra;

      if (isZero && value == 0 || !isZero && value == min) {
        return;
      }
      if (isZero) {
        value = value > min ? value - 1 : 0;
      }
      if (!isZero && value >= min) {
        value = value > min ? value - 1 : min;
      }
      _this.props.changeNumber(value, extra, 'sub', event);
    }, _this.add = function (event) {
      var _this$props2 = _extends({}, _this.props),
          _this$props2$max = _this$props2.max,
          max = _this$props2$max === undefined ? 99 : _this$props2$max,
          value = _this$props2.value,
          _this$props2$min = _this$props2.min,
          min = _this$props2$min === undefined ? 1 : _this$props2$min,
          extra = _this$props2.extra;

      if (value == 0 && value < max) {
        value = min > 0 ? value + min : value + 1;
      } else if (value < max) {
        value = value + 1;
      } else {
        return;
      }
      _this.props.changeNumber(value, extra, 'add', event);
    }, _this.customComponents = [], _temp), _possibleConstructorReturn(_this, _ret);
  }

  _createClass(InputNumber, [{
    key: "_constructor",
    value: function _constructor() {
      _get(InputNumber.prototype.__proto__ || Object.getPrototypeOf(InputNumber.prototype), "_constructor", this).apply(this, arguments);
      this.$$refs = [];
    }
  }, {
    key: "_createData",
    value: function _createData() {
      this.__state = arguments[0] || this.state || {};
      this.__props = arguments[1] || this.props || {};
      var __isRunloopRef = arguments[2];
      var __prefix = this.$prefix;
      ;

      var _props = _extends({}, this.__props),
          value = _props.value,
          _props$isHidden = _props.isHidden,
          isHidden = _props$isHidden === undefined ? false : _props$isHidden;

      var flag = void 0;
      if (isHidden) {
        flag = value > 0 ? true : false;
      } else {
        flag = true;
      }
      Object.assign(this.__state, {
        flag: flag,
        IconSub: IconSub,
        IconAdd: IconAdd,
        value: value
      });
      return this.__state;
    }
  }]);

  return InputNumber;
}(_index.Component), _class.$$events = ["sub", "add"], _class.$$componentPath = "base/InputNumber/index", _temp2);
exports.default = InputNumber;

Component(require('../../npm/@tarojs/taro-weapp/index.js').default.createComponent(InputNumber));