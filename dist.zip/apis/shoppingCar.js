'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _http2 = require('../utils/http.js');

var _http3 = _interopRequireDefault(_http2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ShoppingCarApi = function () {
  function ShoppingCarApi() {
    _classCallCheck(this, ShoppingCarApi);
  }

  _createClass(ShoppingCarApi, null, [{
    key: 'shoppingCarAdd',
    value: function shoppingCarAdd(data) {
      return (0, _http3.default)({
        url: '/api/Goodscart/addInfo',
        data: data
      });
    }
  }, {
    key: 'shoppingCountUpdate',
    value: function shoppingCountUpdate(data) {
      return (0, _http3.default)({
        url: '/api/Goodscart/changeGoodsCartNumber',
        data: data
      });
    }
  }, {
    key: 'shoppingCarDel',
    value: function shoppingCarDel(data) {
      return (0, _http3.default)({
        url: '/api/Goodscart/delInfo',
        data: data
      });
    }
  }, {
    key: 'shoppingCarList',
    value: function shoppingCarList() {
      return (0, _http3.default)({
        url: '/api/Goodscart/getList'
      });
    }
  }]);

  return ShoppingCarApi;
}();

exports.default = ShoppingCarApi;