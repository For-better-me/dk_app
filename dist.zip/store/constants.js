'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
// src/constants/counter.js
var CARCOUNT = exports.CARCOUNT = 'CARCOUNT';
var ORDERNUM = exports.ORDERNUM = 'ORDERNUM';
var CAR_LEN = exports.CAR_LEN = 'CAR_LEN';
var TAB = exports.TAB = 'TAB';
var GOODS_BUYING_LIST = exports.GOODS_BUYING_LIST = 'GOODS_BUYING_LIST';
var ADDR_ID = exports.ADDR_ID = 'ADDR_ID';
var DELIVERY_TYPE = exports.DELIVERY_TYPE = 'DELIVERY_TYPE';