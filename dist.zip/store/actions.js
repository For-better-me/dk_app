"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SetDeliveryType = exports.SetAddrId = exports.SetGoodsBuying = exports.SetCarLen = exports.SetTab = exports.SetCountCar = exports.SetOrderNum = undefined;

var _constants = require("./constants.js");

var SetOrderNum = exports.SetOrderNum = function SetOrderNum(orderNum) {
  return {
    type: _constants.ORDERNUM,
    orderNum: orderNum
  };
};
var SetCountCar = exports.SetCountCar = function SetCountCar(countCar) {
  return {
    type: _constants.CARCOUNT,
    countCar: countCar
  };
};
var SetTab = exports.SetTab = function SetTab(tab) {
  return {
    type: _constants.TAB,
    tab: tab
  };
};
var SetCarLen = exports.SetCarLen = function SetCarLen(len) {
  return {
    type: _constants.CAR_LEN,
    len: len
  };
};
var SetGoodsBuying = exports.SetGoodsBuying = function SetGoodsBuying(list) {
  return {
    type: _constants.GOODS_BUYING_LIST,
    list: list
  };
};
var SetAddrId = exports.SetAddrId = function SetAddrId(id) {
  return {
    type: _constants.ADDR_ID,
    id: id
  };
};
var SetDeliveryType = exports.SetDeliveryType = function SetDeliveryType(val) {
  return {
    type: _constants.DELIVERY_TYPE,
    val: val
  };
};